package hrm.orangehrmtest;

// Login validation using username and password textfield

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginValidation_UsingUNandPwd_TextField 
{
WebDriver driver;
	
	@BeforeMethod
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://orangehrm-demo-6x.orangehrmlive.com/auth/login");
	}
	
	// Login Validation
	// valid case
	@Test (priority=1)
	public void sysadmin_validusernameandpassword()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("_ohrmSysAdmin_");
		driver.findElement(By.id("txtPassword")).sendKeys("sysadmin");
		driver.findElement(By.id("btnLogin")).click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
		
	}
	
	@Test (priority=2)
	public void admin_validusernameandpassword()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		driver.findElement(By.id("btnLogin")).click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
		
	}
	
	@Test (priority=3)
	public void ESSUSER_validusernameandpassword()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("linda");
		driver.findElement(By.id("txtPassword")).sendKeys("linda.anderson");
		driver.findElement(By.id("btnLogin")).click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
		
	}
	
	@Test (priority=4)
	public void supervisor_validusernameandpassword()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("kevin");
		driver.findElement(By.id("txtPassword")).sendKeys("kevin.mathews");
		driver.findElement(By.id("btnLogin")).click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
		
	}
	
	// Invalid case
	
	@Test(priority=5)
	public void rightUserNameWrongPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("admin");
		driver.findElement(By.id("txtPassword")).sendKeys("admin12345");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	
	
	@Test(priority=6)
	public void rightUserNameBlankPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("admin");
		driver.findElement(By.id("txtPassword")).sendKeys("");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	@Test(priority=7)
	public void wrongUserNameRightPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("admin9900");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	@Test(priority=8)
	public void wrongUserNameWrongPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("admin5566");
		driver.findElement(By.id("txtPassword")).sendKeys("admin@123");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	@Test(priority=9)
	public void wrongUserNameBlankPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("testuser");
		driver.findElement(By.id("txtPassword")).sendKeys("");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	@Test(priority=10)
	public void blankUserNameRightPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("");
		driver.findElement(By.id("txtPassword")).sendKeys("admin123");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	@Test(priority=11)
	public void blankUserNameWrongPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("");
		driver.findElement(By.id("txtPassword")).sendKeys("testing@123");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	@Test(priority=12)
	public void blankUserNameBlankPasswordLoginTest()
	{
		driver.findElement(By.id("txtUsername")).clear();
		driver.findElement(By.id("txtPassword")).clear();
		driver.findElement(By.id("txtUsername")).sendKeys("");
		driver.findElement(By.id("txtPassword")).sendKeys("");
		driver.findElement(By.id("btnLogin")).click();
		String ExpectedTitle = "OrangeHRM";
		String ActualTitle = driver.getTitle();
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));	
	}
	
	@AfterMethod
	public void close()
	{
		driver.close();
	}


}
