package hrm.orangehrmtest;

// Login validation using "Login as Different Roles" button

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class LoginValidation_UsingDifferentRolesDropdown 
{
	WebDriver driver;
	
	@BeforeMethod
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://orangehrm-demo-6x.orangehrmlive.com/auth/login");
	}
	
	@Test(priority=1)
	public void LoginAsDifferentRole_SystemAdministrator()
	{
		WebElement login = driver.findElement(By.className("btn-primary"));
		login.click();
		WebElement sysadmin = driver.findElement(By.partialLinkText("System Administrator"));
		sysadmin.click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
	}
	
	@Test(priority=2)
	public void LoginAsDifferentRole_Administrator()
	{
		WebElement login = driver.findElement(By.className("btn-primary"));
		login.click();
		java.util.List<WebElement> list1 = driver.findElements(By.partialLinkText("Administrator"));
		list1.get(1).click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
	}
	
	@Test(priority=3)
	public void LoginAsDifferentRole_ESSUSER()
	{
		WebElement login = driver.findElement(By.className("btn-primary"));
		login.click();
		WebElement ESS_USER = driver.findElement(By.partialLinkText("ESS User"));
		ESS_USER.click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
	}
	
	@Test(priority=4)
	public void LoginAsDifferentRole_1stLevelSupervisor()
	{
		WebElement login = driver.findElement(By.className("btn-primary"));
		login.click();
		WebElement supervisor = driver.findElement(By.partialLinkText("1st Level Supervisor"));
		supervisor.click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
	}
	
	
	
	@AfterMethod
	public void end()
	{
		driver.close();
	}
	



}
