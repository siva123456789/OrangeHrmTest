package hrm.orangehrmtest;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class FetchEmployeeListandLogout 
{
WebDriver driver;
	
	@BeforeMethod
	public void setup()
	{
		System.setProperty("webdriver.chrome.driver", "./Drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.get("https://orangehrm-demo-6x.orangehrmlive.com/auth/login");
	}
	
	@Test(priority=1)
	public void LoginAsDifferentRole_Administrator()
	{
		WebElement login = driver.findElement(By.className("btn-primary"));
		login.click();
		java.util.List<WebElement> list1 = driver.findElements(By.partialLinkText("Administrator"));
		list1.get(1).click();
		WebElement ExpectedTitle = driver.findElement(By.className("page-title"));
		WebElement ActualTitle = driver.findElement(By.className("page-title"));
		Assert.assertTrue(ExpectedTitle.equals(ActualTitle));
		
		// clicking on 'PIM'
		driver.findElement(By.xpath("//span[text()='PIM']")).click();
		
		// clicking on 'Employee list'
		driver.findElement(By.xpath("//span[text()='Employee List']")).click();
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		
		// entering an employee id
		// valid case
		driver.findElement(By.id("employee_name_quick_filter_employee_list_value")).sendKeys("1000");
		driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"quick_search_icon\"]")).click();
		String EmployeeId =driver.findElement(By.xpath("//*[@id=\"employeeListTable\"]/tbody/tr[5]/td[2]")).getText();
		String Name =driver.findElement(By.xpath("//*[@id=\"employeeListTable\"]/tbody/tr[5]/td[3]")).getText();
		String JobTitle =driver.findElement(By.xpath("//*[@id=\"employeeListTable\"]/tbody/tr[5]/td[4]")).getText();
		String Location =driver.findElement(By.xpath("//*[@id=\"employeeListTable\"]/tbody/tr[5]/td[8]")).getText();
		String Supervisor =driver.findElement(By.xpath("//*[@id=\"employeeListTable\"]/tbody/tr[5]/td[9]")).getText();
		System.out.println(EmployeeId +" ");
		System.out.println(Name +" ");
		System.out.println(JobTitle +" ");
		System.out.println(Location +" ");
		System.out.println(Supervisor +" ");
		
	}
		
		@AfterMethod
		public void done() 
		{
			driver.findElement(By.xpath("//*[@id=\"account-job\"]/i")).click();
			WebDriverWait wait2 = new WebDriverWait(driver,30);
			WebElement sample2 = wait2.until(ExpectedConditions.presenceOfElementLocated(By.xpath("/html/body/div[1]/div/div/div[1]/div[2]/div[1]/div/div[2]/ul/li[3]/a")));
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div[2]/div[1]/div/div[2]/ul/li[3]/a")).click();
			WebElement Expectedvalue = driver.findElement(By.id("midPaneContentWrapper"));
			WebElement Actualvalue = driver.findElement(By.id("midPaneContentWrapper"));
			Assert.assertTrue(Expectedvalue.equals(Actualvalue));
			driver.close();
		}


}
